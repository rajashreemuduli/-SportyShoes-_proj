package com.onlyxcodes.app;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class SpringBootRestfulCrudApplicationTests {

/*	@Test
	void contextLoads() {
	}
*/
}
