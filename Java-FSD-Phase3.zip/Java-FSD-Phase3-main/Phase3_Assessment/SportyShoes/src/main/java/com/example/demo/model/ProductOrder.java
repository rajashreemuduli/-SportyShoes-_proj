package com.example.demo;

public class ProductOrder {

	private User user;
	private ProductSQL product;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public ProductSQL getProduct() {
		return product;
	}
	public void setProduct(ProductSQL product) {
		this.product = product;
	}
	
	
}
